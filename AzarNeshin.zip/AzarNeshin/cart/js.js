
let basketContainer = document.querySelector('.container')
let basketProductContainer = document.querySelector('.cart-items')
let cartTotalPriceElem = document.querySelector('.cart-total-price')

let userBasket = []


function getLocalStorage(){
    let localStorageBasket = JSON.parse(localStorage.getItem('products'))

    if(localStorageBasket){
        userBasket = localStorageBasket
    }else{
        userBasket = []
    }
    console.log(userBasket);

    // userBasket.forEach(function(product){
        
    //     let myNewCount = product.count
    //     console.log(myNewCount);
    //     basketProductInput.value = myNewCount
    // })

    basketGenerat(userBasket)
    calcTotalPrice(userBasket)

}



// function addProductToBasketArray(productId){
//     getLocalStorage()

//     userBasket.forEach(function(product){
//         if(product.id === productId){
//             basketGenerat(userBasket)
//             console.log('object');
//         }
//     })

//     console.log(userBasket);
//     userBasket.push(myLocalStorage)
//     calcTotalPrice(userBasket)
// }

// console.log(myLocalStorage);


function basketGenerat(basketArray){
    
    // basketProductContainer.innerHTML = ''

    basketArray.forEach(function(product){

        let basketProductImg = document.createElement('img')
        basketProductImg.setAttribute('src', product.img)
        basketProductImg.setAttribute('width', '100')
        basketProductImg.setAttribute('height', '100')
        basketProductImg.style.borderRadius = '50%'
    
        let basketProductTitle = document.createElement('span')
        basketProductTitle.classList.add('cart-item-title')
        basketProductTitle.innerHTML = product.title
    
    
            
        let basketProductPrice = document.createElement('span')
        basketProductPrice.classList.add('cart-price')
        basketProductPrice.innerHTML = product.price
    
        let basketProductInput = document.createElement('input')
        basketProductInput.className = 'cart-quantity-input'
        basketProductInput.value = product.count
        basketProductInput.setAttribute('type', 'number')
        basketProductInput.setAttribute('min', '1')
        basketProductInput.addEventListener('change', function(){
            updateProductCount(product.id, basketProductInput.value)
        })
        
   
    

        // let basketProductTotalPrice = document.createElement('span')
        // basketProductTotalPrice.classList.add('cart-items')
        // basketProductTotalPrice.innerHTML = '0'

        let basketProductDeleteProduct = document.createElement('button')
        basketProductDeleteProduct.classList.add('cart-delete')
        basketProductDeleteProduct.innerHTML = 'حذف'

        basketProductDeleteProduct.addEventListener('click', function(){
            removeProductFromBasket(product.id)
        })

    
    
    
        basketProductContainer.append(basketProductImg,basketProductTitle,basketProductPrice,basketProductInput,basketProductDeleteProduct)

        calcTotalPrice(userBasket)

    
    
        // basketContainer.append(basketProductContainer)  
    })
}

function setLocalStorage(userBasketArray){
    localStorage.setItem('products', JSON.stringify(userBasketArray))
}




function calcTotalPrice (userBasketArray){
    let totalPriceValue = ''
    
    userBasketArray.forEach(function(product){
        totalPriceValue += product.price * product.count
    })


    cartTotalPriceElem.innerHTML = totalPriceValue   
}

function updateProductCount(productId, newCount){
    console.log('product id:' + productId + 'new Count:' + newCount);

    userBasket.forEach(function(product){
        if(product.id === productId){
            product.count = newCount
        }
    })

    calcTotalPrice(userBasket)

}




function removeProductFromBasket(productId){
    // let myLocalStorage = JSON.parse(localStorage.getItem('todos'))

    // userBasket = myLocalStorage
    // userBasket.forEach(function(product){
    //     console.log(product.id);
    // })
    
    let mainBasketIndex = userBasket.findIndex(function(product){
        return product.id === productId
    })
    console.log(mainBasketIndex);
    userBasket.splice(mainBasketIndex, 1)
    location.reload()

    basketGenerat(userBasket)
    setLocalStorage(userBasket)


}


window.addEventListener('load', getLocalStorage)