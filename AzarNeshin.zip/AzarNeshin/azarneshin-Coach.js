let header = document.querySelector(".main-header")
let menuItemElem = document.querySelectorAll('.menu-item')
let shopingIcon = document.querySelector('.fa-shopping-cart')
let porfileIcon = document.querySelector('.fa-address-book')
let shopingCountIconBgColor = document.head.appendChild(document.createElement('style'))
let shopingCountIconColor = document.head.appendChild(document.createElement('style'))
// let body = document.querySelector('body')
let supportSectionImageMoving = document.querySelector('.support-section-image')
let inputElem = document.querySelector('.header-input-elem')

document.addEventListener('scroll', function(){
    if(document.documentElement.scrollTop > 0){
        header.classList.add('sticky-header')
        menuItemElem.forEach(function(item){
            item.style.color = 'black'
        })
        shopingIcon.style.color = 'black'
        porfileIcon.style.color = 'black'

        shopingCountIconBgColor.innerHTML = '.header-left::before {background-color: black;}'
        shopingCountIconColor.innerHTML = '.header-left::before {color: #fff'
        inputElem.style.backgroundColor = "#CFD8DC"
        

    }else{
        header.classList.remove('sticky-header')
        menuItemElem.forEach(function(item){
            item.style.color = '#fff'
        })
        shopingIcon.style.color = '#fff'
        porfileIcon.style.color = '#fff'
        shopingCountIconBgColor.innerHTML = '.header-left::before {background-color: #fff;}'
        shopingCountIconColor.innerHTML = '.header-left::before {color: black'
        inputElem.style.backgroundColor = '#fff'
    }
})


document.addEventListener('mousemove', function(event){
    console.log('majaja');
    console.log(event.pageX);
    console.log(window.innerHeight);
    let x = event.clientX / window.innerHeight;
    let y = event.clientY / window.innerWidth;
    x = x * -30;
    y = y * -100;
    supportSectionImageMoving.style.transform = 'translate(' + x + 'px,' + y + 'px';
 
    // let translateXElem = supportSectionImageMoving.style.transform = 'translateX()'
    // console.log(translateXElem);
})