let myHeader = document.querySelector('.header')
let myIntroductionScroll = document.querySelector('.introduction-section-left')
let addToBasketElem = document.querySelector('.add-to-basket-link')
let inputCount = document.querySelector('.count-input')

let myProduct = [
    { id: 1, title:"وی ایزوله اپلاید", price: '3890000' , img: '../../Images/IMG-20221027-WA0000-400x400.jpg', count: 1}
]

let userBasket = []

myProduct.forEach(function(prodcut){
    addToBasketElem.addEventListener('click', function(event){
        event.preventDefault()
        addProductToBasketArray(prodcut.id)
        location.href = 'http://127.0.0.1:5500/cart/'
    })
})


function addProductToBasketArray (productId) {
    let mainProduct = myProduct.find(function(product){
        return product.id === productId
    })
    // console.log(mainProduct);

    userBasket.push(mainProduct)
    console.log(userBasket);
    setLocalStorage(userBasket)
}

function setLocalStorage(userBasketArray){
    localStorage.setItem('products', JSON.stringify(userBasketArray))
}

function getLocalStorage(){
    let myLocal = JSON.parse(localStorage.getItem('products'))
}


myProduct.forEach(function(product){
    inputCount.addEventListener('change', function(){
        changeCount(product.id, inputCount.value)
    })
})


function changeCount(productId, newCount){
    console.log('product id: ' + productId , 'new Count: ' + newCount);

    myProduct.forEach(function(product){
        if(product.id === productId){
            product.count = newCount
            // setLocalStorage(userBasket)
        }
    })
    console.log(userBasket);
}


window.addEventListener('load', getLocalStorage)










document.addEventListener("scroll", function(){
    console.log('ajaja');
    if(document.documentElement.scrollTop > 200){
        myHeader.classList.add('sticky-header')
    }else{
        myHeader.classList.remove('sticky-header')
    }
})

